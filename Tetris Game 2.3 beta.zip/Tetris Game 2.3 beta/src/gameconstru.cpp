#include "../include/gameconstru.h"
#include <unistd.h>

void motion::makeit(int pigment) {
    int i;
    int j;
    piecesPosi p;

    for(i = x; i < x+3; i++) {
        for (j = y; j < y + 3; j++) {
            if (a[i - x][j - y] == 1) {
                p.deciposition(i, j);
                p.decicol(pigment);
                p.printPoint();
            }
        }
    }
}


int motion::move(int dir) {
	switch(dir) {
		case DOWN:
		    x++;
		    break;
		case LEFT:
		    y--;
		    break;
		case RIGHT:
		    y++;
		    break;
		default:
		    break;
	}
    return 0;
}


int motion::randdd() {
    int i;
    int j;
    int b[3][3];
    for(i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            b[2 - j][i] = a[i][j];
        }
    }

    for(i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            a[i][j] = b[i][j];
        }
    }
}


