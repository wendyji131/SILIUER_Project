#include "../include/randcreate.h"
#include <ctime>
#include <stdlib.h>
#include <iostream>

using namespace std;


Rand::Rand() {
    srand(unsigned(time(0)));
}

int Rand::possibleX(int x,int y) {
    int possibleX;
    double random(double,double);
    possibleX = int(random(x,y));
    return possibleX;
}

double random(double start,double end) {
    return start + (end - start)*rand()/(RAND_MAX + 1.0);
}
