#include"../include/piecechange.h"
#include<cstdio>
#include<cstdlib>

void rightnow::makemove(const int x,const int y) {
	int i;
	for(i = 0; i < y; i++) {
		printf("\33[2C");
	}

	for(i = 0; i < x; i++) {
		printf("\33[1B");
	}
}

void rightnow::getPieces() {
	printf("\33[s");	
}

void rightnow::savePieces() {
	printf("\33[u");
}









