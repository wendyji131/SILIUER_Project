#include "../include/gameresult.h"
#include "../include/piecechange.h"
#include "../include/pieceConstru.h"

void Score::giveinfo()
{
   rightnow c;
   piecesPosi p;

   p.deciposition(2,19);
   p.printPoint();
   
   c.getPieces();
   c.makemove(2,21);
   c.savePieces();

   p.deciposition(4,19);
   p.decicol(GREN);
   p.printPoint();

   c.getPieces();
   c.makemove(4,21);
   cout<<"current score : "<<score;

   c.savePieces();
}
