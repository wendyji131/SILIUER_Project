#ifndef RANDD_H
#define RANDD_H
class Rand
{
public:
    int possibleX(int x,int y);
    Rand();
};

#endif
