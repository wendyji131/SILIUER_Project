#include <iostream>
#include <stdio.h>
#include "pieceConstru.h"
#include <stdlib.h>

#define DOWN 0
#define LEFT 1
#define RIGHT 2

using namespace std;

class motion{
public:
	motion(){
		int i,j;
		x = 0;
		y = 0;
		for(j = 0; j < 3; j++)
		for(i = 0; i < 3; i++)
		a[i][j] = 0;
	}

	int move(int dir);
	virtual int randdd();

    void fetchposi(int* a,int* b){
    	*a = x;*b = y;
    }

    void makeit(int pigment);

	void* fetchinfo(){
		return (void*)a;
	}

	virtual void making(){

	}
	void deciposition(int a,int b){
		x = a;y = b;
	}

protected:
	int x, y;
	int a[3][3];

};


class pieceT : public motion{
public:
    void making(){
        a[0][0] = 1;
        a[0][1] = 1;
        a[0][2] = 1;
        a[1][0] = 0;
        a[1][1] = 1;
        a[1][2] = 0;
        a[2][0] = 0;
        a[2][1] = 0;
        a[2][2] = 0;
    }
};


class pieceZ : public motion{
public:
	void making(){
		a[0][0] = 1;
		a[0][1] = 1;
		a[0][2] = 0;
		a[1][0] = 0;
		a[1][1] = 1;
		a[1][2] = 1;
		a[2][0] = 0;
		a[2][1] = 0;
		a[2][2] = 0;
	}
};


class pieceO : public motion{
public:
	void making(){
		a[0][0] = 1;
		a[0][1] = 1;
		a[0][2] = 0;
		a[1][0] = 1;
		a[1][1] = 1;
		a[1][2] = 0;
		a[2][0] = 0;
		a[2][1] = 0;
		a[2][2] = 0;
	}
	virtual int randdd(){}
};


class pieceL : public motion{
public:
	void making(){
		a[0][0] = 0;
		a[0][1] = 1;
		a[0][2] = 0;
		a[1][0] = 0;
		a[1][1] = 1;
		a[1][2] = 0;
		a[2][0] = 0;
		a[2][1] = 1;
		a[2][2] = 1;
	}
};


class pieceI : public motion{
public:
    void making(){
        a[0][0] = 0;
        a[0][1] = 1;
        a[0][2] = 0;
        a[1][0] = 0;
        a[1][1] = 1;
        a[1][2] = 0;
        a[2][0] = 0;
        a[2][1] = 1;
        a[2][2] = 0;
    }
};


class inclu
{
private:
	motion* motioncontr;
    pigment clr;

public:
    ~inclu()
    {
        delete motioncontr;
    }
	inclu(char cType)
	{
		switch(cType)
		{
			case 'Z':
				motioncontr = new pieceZ();
				clr = PURPLE;
				break;
			case 'T':
				motioncontr = new pieceT();
				clr = PURPLE;
				break;
			case 'O':
				motioncontr = new pieceO();
				clr = PURPLE;
				break;
			case 'I':
				motioncontr = new pieceI();
				clr = PURPLE;
				break;
			case 'L':
				motioncontr = new pieceL();
				clr = PURPLE;
				break;
			default:
				break;
		}
	}

	int move(int dir){
    	return motioncontr->move(dir);
    }

	int randdd(){
    	return motioncontr->randdd();
    }

	void making(){
    	motioncontr->making();
    }

	void deciposition(int a,int b){
    	motioncontr->deciposition(a,b);
    }

    void fetchposi(int *a,int* b){
    	motioncontr->fetchposi(a,b);
    }

    void* fetchinfo(){
    	motioncontr->fetchinfo();
    }

    void makeit(int pigment){
	if(pigment == CLEAR)
		motioncontr->makeit(CLEAR);
	else motioncontr->makeit(clr);
	}

	void decicol(pigment clr) {
		this->clr = clr;
	}

    pigment decicol() {
	return clr;
	}
};

