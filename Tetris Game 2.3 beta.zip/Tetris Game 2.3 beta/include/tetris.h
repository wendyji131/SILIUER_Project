#include "gameconstru.h"
#include "randcreate.h"
#include "gameresult.h"

enum gameState{
	stateP = 0,
	stateRunning = 1
};


class TetrisCore {
public:
    int x;
    int y;
    TetrisCore();
	~TetrisCore();
	gameState fetchState();
    void craftPiece();
    void randdd();
    void getend();
    void eliminLine();
	void move(int dir);
    void dropPiece(int level);
	void prepTetris();
	void deciState( gameState );
	void piecePrint(inclu* GUI);

private:
	Score s;
	int tBoard[24][17];
	pigment tCol[24][17];
	inclu* GUI;
	inclu* makeGUI;
	gameState currt;
	bool redoBoard();
	bool checkDown();
	bool checkR();
	char choosePiece();
	bool prepBoard();
	bool clearBoard();
	bool checkL();
};
