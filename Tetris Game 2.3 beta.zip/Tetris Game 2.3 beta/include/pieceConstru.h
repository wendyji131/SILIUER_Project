#ifndef piecesPosi_H_
#define piecesPosi_H_

#include<iostream>
#include "piecechange.h"

using namespace std;

enum pigment{
	CLEAR = 0, BLACK = 30, YELLOW, PURPLE, GREN
};

class piecesPosi{
public:
    piecesPosi() {
        pigment = CLEAR;
		x = 0;
		y = 0;
	}

    piecesPosi(int a,int b,int c) {
        pigment = a;
		x = b;
		y = c;
	}

    int decicol(){
        return pigment;
    }

	void deciposition(const int x,const int y){
        this->x = x;
        this->y = y;
    }

	void decicol(const int pigment){
        this->pigment = pigment;
    }

	void fetchposi(int&x,int &y){
        x = this->x;
        y = this->y;
    }

	void printPoint();

protected:
	int x, y, pigment;
};
#endif

