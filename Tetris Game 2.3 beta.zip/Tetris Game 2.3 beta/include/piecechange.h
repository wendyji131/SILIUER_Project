#ifndef NOW_H_
#define NOW_H_

#include<iostream>

using namespace std;

class rightnow{
public:
	void getPieces();
	void savePieces();
	void makemove(const int x,const int y);
};
#endif

