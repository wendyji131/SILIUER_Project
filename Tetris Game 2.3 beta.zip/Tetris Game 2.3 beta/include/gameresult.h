#ifndef RESULT_H
#define RESULT_H

#include <iostream>
#include <string>

using namespace std;

class Score{
public:
    int score;
    string player;

    Score(){
        player = "Toni";
        score = 0;
    };

    void giveinfo();
    void initialresult(int s){
        score = s;
    };
};

#endif
