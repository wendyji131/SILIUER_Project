//
// Created by wendyji on 12/6/18.
//

#ifndef TETRIS_PLAYGAMEHANDLER_H
#define TETRIS_PLAYGAMEHANDLER_H

#include <memory>
#include "Tetris.h"

namespace Domain::GameRule{
    // GameRule Package within the Domain Layer Abstract class
    struct PlayGameHandler
    {
        // Constructors and assignment operations
        PlayGameHandler()                                                        = default;  // default ctor
        PlayGameHandler( const PlayGameHandler &  original )                = default;  // copy ctor
        PlayGameHandler(       PlayGameHandler && original )                = default;  // move ctor

        virtual PlayGameHandler & operator=( const PlayGameHandler &  rhs ) = default;  // copy assignment
        virtual PlayGameHandler & operator=(       PlayGameHandler && rhs ) = default;  // move assignment

        // Operations

        // Destructor
        // Pure virtual destructor helps force the class to be abstract, but must still be implemented
        virtual ~PlayGameHandler() noexcept = 0;
    }; // class PlayGameHandler





    /*****************************************************************************
    ** Inline implementations
    ******************************************************************************/
    inline PlayGameHandler::~PlayGameHandler() noexcept
    {}
}


#endif //TETRIS_PLAYGAMEHANDLER_H
