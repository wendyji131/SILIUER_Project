//
// Created by wendyji on 12/4/18.
//

#ifndef TETRIS_SCORE_H
#define TETRIS_SCORE_H

#include <iostream>
#include <string>

using namespace std;

class Score{
public:
    int score;
    string player;

    Score(){
        player = "Toni";
        score = 0;
    };

    void giveinfo();
    void initialScore(int s){
        score = s;
    };
};


#endif //TETRIS_SCORE_H
