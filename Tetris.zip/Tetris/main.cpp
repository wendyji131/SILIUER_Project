#include "Domain/GameRule/Tetris.h"
#include "Domain/GameRule/player.h"
#include "Domain/GameRule/PlayGameHandler.h"


int main() {
    std::cout << "Hello, World!" << std::endl;
    Domain::GameRule::Tetris g;
    g.playGame();

    return 0;
}



