//
// Created by wendyji on 12/4/18.
//

#ifndef TETRIS_USERINTERFACEHANDLER_H
#define TETRIS_USERINTERFACEHANDLER_H

using namespace std;

unsigned long line_num = 0;



namespace UI
{
    // User Interface Layer Abstract class
    struct UserInterfaceHandler
    {
        // Constructors and assignment operations
        UserInterfaceHandler()                                                = default;    // default ctor
        UserInterfaceHandler( const UserInterfaceHandler &  original )        = default;    // copy ctor
        UserInterfaceHandler(       UserInterfaceHandler && original )        = default;    // move ctor

        virtual UserInterfaceHandler & operator=( const UserInterfaceHandler &  rhs ) = default;    // copy assignment
        virtual UserInterfaceHandler & operator=(       UserInterfaceHandler && rhs ) = default;    // move assignment


        // Operations
        virtual void launch() = 0;


        // Abstract class destructor
        virtual ~UserInterfaceHandler() noexcept = 0;  // must be virtual and pure
    };


    /*****************************************************************************
    ** Inline implementations
    ******************************************************************************/
    inline UserInterfaceHandler::~UserInterfaceHandler() noexcept
    {}


} // namespace UI

#endif //TETRIS_USERINTERFACEHANDLER_H
