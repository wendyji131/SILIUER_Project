#include <stdio.h>

#include "UI.hpp"
#include "RegisterLogin.hpp"
#include "UIheadler.hpp"
#include "security.hpp"
#include "DB.hpp"

int main() {
    
//    UI::launch();
    Domain::RegisterLogin::Register();
    
//    string nihao = "hello";
//    string nibuhao = TechnicalServices::Security::encryption(nihao);
//    std::cout << nibuhao << std::endl;
    
    
    return 0;
}
