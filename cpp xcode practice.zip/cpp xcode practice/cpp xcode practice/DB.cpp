#include "DB.hpp"

namespace TechnicalServices::Persistence {
    
    void runQueries (std::ifstream &infile) {
        TextQuery tq(infile);
        
        cout << "\tEnter your user name: ";
        std::string s;
        cin >> s;
        
        print(std::cout, tq.query(s)) << std::endl;
        
    }
    
    int enu_line(char *filename) {
        ifstream outFile;
        int n = 0;
        string clause;
        
        outFile.open(filename, ios::in);
        
        if(outFile.fail()) {
            return 0;
        }
        else
        {
            while(getline(outFile, clause)) {
                n++;
            }
            outFile.close();
            
            return n;
        }
    }
    
    
    string know_line(char *filename, int line)
    {
        int lines, i = 0;
        string clause;
        fstream outfile;
        outfile.open(filename, ios::in);
        lines = enu_line(filename);
        
        while(getline(outfile, clause) && i < line-1) {
            i++;
        }
        outfile.close();
        return clause;
    }
    
    
    TextQuery::TextQuery(std::ifstream &is) : file(new std::vector<std::string>) {
        std::string text;
        
        while (std::getline(is, text)) {
            
            file->push_back(text);
            auto n = file->size() - 1;
            std::istringstream line(text);
            std::string word;
            
            while (line >> word) {
                auto& lines = wm[word];
                if (!lines)
                    lines.reset(new set<line_no>);
                lines->insert(n);
            }
        }
    }
    
    
    QueryResult TextQuery::query(const std::string& sought) const {
        static std::shared_ptr<std::set<line_no>> nodata(new std::set<line_no>);
        auto loc = wm.find(sought);
        
        if (loc == wm.end())
            return QueryResult(sought, nodata, file);
        else
            return QueryResult(sought, loc->second, file);
    };
    
    
    std::string make_plural (std::size_t ctr, const std::string& word, const std::string ending) {
        return (ctr > 1) ? word + ending : word;
    }
    
    
    
    std::ostream& print(std::ostream& os, const QueryResult &qr) {
        
        for(auto num : *qr.lines) {
            line_num = num + 1;
        }
        return os;
    }
    
    
    
    
    
    
    void save_to_Txt(std::string playerinfo) {
        
        std::ofstream outFile;
        outFile.open("private.txt",std::ios::app);
        
        outFile << playerinfo;
        outFile << std::endl;
        
        outFile.close();
        
    }
    
    
    
}
