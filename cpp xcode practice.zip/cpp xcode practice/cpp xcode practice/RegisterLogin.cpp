#include "RegisterLogin.hpp"
#include "DB.hpp"
#include "UI.hpp"
#include "security.hpp"

#include <iostream>
#include <fstream>

using namespace std;

namespace Domain::RegisterLogin {
    
    void Register () {
        
        string name;
        
        
        cout << endl << endl;
        cout << "******************Register******************" << endl;
        cout << "-User Name should be combination of less than digits or letters.\n";
        
        {


            cout << "-The length of username should be 5.";
            name = setUsername();

            ifstream infile;
            infile.open("private.txt");
            TechnicalServices::Persistence::runQueries(infile);
            infile.close();

            if (TechnicalServices::Persistence::line_num != 0) {
                cout << "username already exists, please change your username!" << endl;
                TechnicalServices::Persistence::line_num = 0;

                cout << "-The length of username should be 5.";
                name = setUsername();

                ifstream infile;
                infile.open("private.txt");
                TechnicalServices::Persistence::runQueries(infile);
                infile.close();

                if (TechnicalServices::Persistence::line_num != 0) {
                    cout << "username already exists, please change your username!" << endl;
                    TechnicalServices::Persistence::line_num = 0;
                    cout << "-The length of username should be 5.";
                    name = setUsername();

                }

            }

            cout << "\n-Password should be combination of 8 digits or letters";

            string psd = setPassword();

            string new_psd = TechnicalServices::Security::encryption(psd);

            TechnicalServices::Persistence::save_to_Txt(name);
            TechnicalServices::Persistence::save_to_Txt(new_psd);


            TechnicalServices::Persistence::line_num = 0;

//            displaygameMenu();
        }
        
        
        
    }
    


    string setUsername() {

        string name;
        cout << endl << endl;
        cout << "\tEnter your user name: ";
        cin >> name;
        for (int i=0; i<name.length(); i++){
            if ( !isalnum(name[i]) ){
                cout << endl;
                cout << "Your username should be combination of digits or letters!";
                cout << endl ;
                cout << "Please reset your username!";
                cout << endl;
                setUsername();
                break;
            }
        }

        while (name.length() != 5){
            cout << "The length of the username should be 5!";
            cout << endl;
            cout << "Please reset your username!";
            cout << endl << endl;
            return setUsername();
        }

        return name;
    }

    string setPassword(){
        string psw1, psw2;
        cout << endl;
        cout << "\tSet your password: ";
        cin >> psw1;
        while(!Domain::RegisterLogin::checkPassword(psw1)) {
            cout << "\tSet your password: ";
            cin >> psw1;
        }

        cout << "\tRepeat your password: ";
        cin >> psw2;

        if (psw1==psw2){
            return psw1;
        }
        else
            return "0";
//        else{
//            cout << endl;
//            cout << "\t\tDifferent Password!" << endl;
//            return setPassword();
//        }
    }


    bool checkPassword(string& psw){
        for (int i=0; i<psw.length(); i++){
            if ( !isalnum(psw[i]) ){
                cout << endl;
                cout << "\nYour password should be combination of digits or letters!";
                cout << endl ;
                cout << "Please reset your password!";
                cout << endl;
                return 0;

            }
        }

        while (psw.length()!= 8){
            cout << "\nThe length of the password should be 8!";
            cout << endl;
            cout << "Please reset your password!";
            cout << endl << endl;
            return 0;

        }
        return 1;
    }


    //--------------
    void runQueries (std::ifstream &infile) {
        TextQuery tq(infile);
        
        cout << "\tEnter your user name: ";
        std::string s;
        cin >> s;
        
        print(std::cout, tq.query(s)) << std::endl;
        
    }
    
    int enu_line(char *filename) {
        ifstream outFile;
        int n = 0;
        string clause;
        
        outFile.open(filename, ios::in);
        
        if(outFile.fail()) {
            return 0;
        }
        else
        {
            while(getline(outFile, clause)) {
                n++;
            }
            outFile.close();
            
            return n;
        }
    }
    
    
    string know_line(char *filename, int line)
    {
        int lines, i = 0;
        string clause;
        fstream outfile;
        outfile.open(filename, ios::in);
        lines = enu_line(filename);
        
        while(getline(outfile, clause) && i < line-1) {
            i++;
        }
        outfile.close();
        return clause;
    }
    
    
    TextQuery::TextQuery(std::ifstream &is) : file(new std::vector<std::string>) {
        std::string text;
        
        while (std::getline(is, text)) {
            
            file->push_back(text);
            auto n = file->size() - 1;
            std::istringstream line(text);
            std::string word;
            
            while (line >> word) {
                auto& lines = wm[word];
                if (!lines)
                    lines.reset(new set<line_no>);
                lines->insert(n);
            }
        }
    }
    
    
    QueryResult TextQuery::query(const std::string& sought) const {
        static std::shared_ptr<std::set<line_no>> nodata(new std::set<line_no>);
        auto loc = wm.find(sought);
        
        if (loc == wm.end())
            return QueryResult(sought, nodata, file);
        else
            return QueryResult(sought, loc->second, file);
    };
    
    
    std::string make_plural (std::size_t ctr, const std::string& word, const std::string ending) {
        return (ctr > 1) ? word + ending : word;
    }
    
    
    
    std::ostream& print(std::ostream& os, const QueryResult &qr) {
        
        for(auto num : *qr.lines) {
            line_num = num + 1;
        }
        return os;
    }
    
    
    
    
    
    
    void save_to_Txt(std::string playerinfo) {
        
        std::ofstream outFile;
        outFile.open("private.txt",std::ios::app);
        
        outFile << playerinfo;
        outFile << std::endl;
        
        outFile.close();
        
    }

}

