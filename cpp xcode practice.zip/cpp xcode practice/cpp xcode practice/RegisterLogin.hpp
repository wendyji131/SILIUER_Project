#include <stdio.h>

#include <string>

#include <stdio.h>
#include <unistd.h>
#include <semaphore.h>
#include <cstring>
#include <cstdio>
#include <iostream>
#include <string>
#include <cctype>
#include <fstream>
#include <sstream>
#include <vector>
#include <memory>
#include <set>
#include <map>

namespace Domain::RegisterLogin {
    void Register();
    std::string setUsername();
    std::string setPassword();
    bool checkPassword(std::string& psw);
    
    
    class QueryResult {
        friend std::ostream& print (std::ostream&, const QueryResult& );
    public:
        using line_no = std::vector<std::string>::size_type;
        
        QueryResult (std::string s,
                     std::shared_ptr<std::set<line_no>> p,
                     std::shared_ptr<std::vector<std::string>> f) :
        sought(s), lines(p), file(f) {}
        
    private:
        std::string sought;
        std::shared_ptr<std::set<line_no>> lines;
        std::shared_ptr<std::vector<std::string>> file;
    };
    
    unsigned long line_num = 0;
    void save_to_Txt(std::string playerinfo);
    int enu_line(char *filename);
    std::string know_line(char *filename, int line);
    std::ostream& print(std::ostream& os, const QueryResult &qr);
    
    void runQueries (std::ifstream &infile);
    
    class TextQuery {
    public:
        using line_no = std::vector<std::string>::size_type;
        TextQuery(std::ifstream& );
        QueryResult query(const std::string& ) const;
    private:
        std::shared_ptr<std::vector<std::string> > file;
        std::map<std::string, std::shared_ptr<std::set<line_no> >> wm;
    };
    
    
    
    
    void save_to_Txt(std::string playerinfo);
    
    
    
    
}
