#include <iostream>
#include "UI.hpp"


using namespace std;

namespace UI
{
    void launch(){
        displayMainMenu();
        int choice = makeChoice();
        std::cout << choice << std::endl;
        
        
    }
    
    
    
} // namespace UI
