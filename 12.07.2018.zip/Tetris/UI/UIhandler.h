#include <iostream>
#include "UI.h"
#include "../Domain/RegisterLogin/RegisterLoginHandler.h"

using namespace std;

namespace UI
{
    void launch();

} // namespace UI
