#include "security.h"

#include <stdio.h>
#include <unistd.h>
#include <semaphore.h>
#include <cstring>
#include <cstdio>
#include <iostream>
#include <string>
#include <cctype>
#include <fstream>
#include <sstream>
#include <vector>
#include <memory>
#include <set>
#include <map>

using namespace std;

namespace TechnicalServices::Persistence {
    

}
