#include <stdio.h>
#include <string>

namespace TechnicalServices::Security {
    
    std::string encryption(std::string& c);
    std::string decode(std::string& c);
    
    
}
