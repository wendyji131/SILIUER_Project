//
// Created by wendyji on 12/4/18.
//

#ifndef TETRIS_LOGGERHANDLER_H
#define TETRIS_LOGGERHANDLER_H
#include <iostream>
#include <string>

#include "../../UI/UserInterfaceHandler.h"
#include "../../TechnicalServices/Persistence/PersistenceHandler.h"

namespace UI
{
    /*****************************************************************************
    ** Simple UI definition
    **   Simple UI is a console application meant only as a driver to the Domain Layer application. This UI will someday be replaced
    **   by a more sophisticated, user friendly implementation
    ******************************************************************************/
    class SimpleUI : public UI::UserInterfaceHandler
    {
    public:
        using UserInterfaceHandler::UserInterfaceHandler;  // inherit constructors
        SimpleUI();

        // Operations
        void launch() override;


        // Destructor
        ~SimpleUI() noexcept override;


    private:
        // These smart pointers hold pointers to lower architectural layer's interfaces
        //std::unique_ptr<Domain::Library::MaintainBooksHandler>                _bookHandler;
        //std::unique_ptr<TechicalServices::Persistence::PersistenceHandler>    _persistentData;
        //std::unique_ptr<TechicalServices::Logging::LoggerHandler>             _loggerPtr;
        //std::unique_ptr<Domain::AccountManagement::AccountManagementHandler>  _accounts;


        // convenience reference object enabling standard insertion syntax
        // This line must be physically after the definition of _loggerPtr
        //TechicalServices::Logging::LoggerHandler                            & _logger = *_loggerPtr;
    };
} // namespace UI
#endif //TETRIS_LOGGERHANDLER_H
