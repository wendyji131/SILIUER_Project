#include "Score.h"
#include "cursor.h"
#include "gameBoard.h"

void Score::giveinfo()
{
    cursor c;
    gameBoard p;

    p.decidePosition(2,19);
    p.printPoint();

    c.saveCursor();
    c.moveCursor(2,21);
    c.resetCursor();

    p.decidePosition(4,19);
    p.decicol(GREN);
    p.printPoint();

    c.saveCursor();
    c.moveCursor(4,21);
    cout<<"current score : "<<score;

    c.resetCursor();
}