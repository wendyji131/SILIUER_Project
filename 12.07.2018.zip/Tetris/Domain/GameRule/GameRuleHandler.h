//
// Created by wendyji on 12/7/18.
//

#ifndef CPP_XCODE_PRACTICE_GAMERULEHANDLER_H
#define CPP_XCODE_PRACTICE_GAMERULEHANDLER_H
namespace Domain::GameRule{
    //gameRuleController display the gameMenu, and promote the user to make choice
    //then control the further procedure depending on the user's choice
    void gameRuleController();
    void displayGameMenu();
    int makeChoice();

}
#endif //CPP_XCODE_PRACTICE_GAMERULEHANDLER_H
