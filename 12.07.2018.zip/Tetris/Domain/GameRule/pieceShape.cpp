//
// Created by wendyji on 12/4/18.
//

#include "pieceShape.h"
#include <unistd.h>

void pieceShape::makeit(int pigment) {
    int i;
    int j;
    gameBoard p;

    for(i = x; i < x+3; i++) {
        for (j = y; j < y + 3; j++) {
            if (a[i - x][j - y] == 1) {
                p.decidePosition(i, j);
                p.decicol(pigment);
                p.printPoint();
            }
        }
    }
}


int pieceShape::move(int dir) {
    switch(dir) {
        case DOWN:
            x++;
            break;
        case LEFT:
            y--;
            break;
        case RIGHT:
            y++;
            break;
        default:
            break;
    }
    return 0;
}


int pieceShape::rotatePiece() {
    int i;
    int j;
    int b[3][3];
    for(i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            b[2 - j][i] = a[i][j];
        }
    }

    for(i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            a[i][j] = b[i][j];
        }
    }
}