//
// Created by wendyji on 12/7/18.
//

#ifndef CPP_XCODE_PRACTICE_GAMERULE_H
#define CPP_XCODE_PRACTICE_GAMERULE_H
namespace Domain::GameRule{
    void playGame();
    void gameInstruction();
    void highScore();
    void puchase();
    void Logout();
}
#endif //CPP_XCODE_PRACTICE_GAMERULE_H
