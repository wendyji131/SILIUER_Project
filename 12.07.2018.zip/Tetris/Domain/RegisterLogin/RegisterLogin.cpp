#include "RegisterLogin.h"
#include "../../TechnicalServices/Security/security.h"
#include "../../UI/UIhandler.h"
#include "../../Domain/GameRule/GameRuleHandler.h"
#include <iostream>
#include <fstream>

using namespace std;

namespace Domain::RegisterLogin {
    unsigned long line_num = 0;

    class QueryResult {
        friend std::ostream& print (std::ostream&, const QueryResult& );
    public:
        using line_no = std::vector<std::string>::size_type;

        QueryResult (std::string s,
                     std::shared_ptr<std::set<line_no>> p,
                     std::shared_ptr<std::vector<std::string>> f) :
                sought(s), lines(p), file(f) {}

    private:
        std::string sought;
        std::shared_ptr<std::set<line_no>> lines;
        std::shared_ptr<std::vector<std::string>> file;
    };

    class TextQuery {
    public:
        using line_no = std::vector<std::string>::size_type;
        TextQuery(std::ifstream &is) : file(new std::vector<std::string>) {
            std::string text;

            while (std::getline(is, text)) {

                file->push_back(text);
                auto n = file->size() - 1;
                std::istringstream line(text);
                std::string word;

                while (line >> word) {
                    auto& lines = wm[word];
                    if (!lines)
                        lines.reset(new std::set<line_no>);
                    lines->insert(n);
                }
            }
        }
        QueryResult query(const std::string& ) const;
    private:
        std::shared_ptr<std::vector<std::string> > file;
        std::map<std::string, std::shared_ptr<std::set<line_no> >> wm;
    };




    std::string make_plural (std::size_t ctr, const std::string& word, const std::string ending) {
        return (ctr > 1) ? word + ending : word;
    }

    std::ostream& print(std::ostream& os, const QueryResult &qr) {

        for(auto num : *qr.lines) {
            line_num = num + 1;
        }
        return os;
    }

    int enu_line(char *filename) {
        ifstream outFile;
        int n = 0;
        std::string clause;

        outFile.open(filename, ios::in);

        if(outFile.fail()) {
            return 0;
        }
        else
        {
            while(getline(outFile, clause)) {
                n++;
            }
            outFile.close();

            return n;
        }
    }


    void runQueries (std::ifstream &infile) {
        TextQuery tq(infile);

        cout << "\tEnter your user name: ";
        std::string s;
        cin >> s;

        print(std::cout, tq.query(s)) << std::endl;

    }

    string setUsername(){
        string name;
        cout << endl << endl;
        cout << "\tEnter your user name: ";
        cin >> name;
        for (int i=0; i<name.length(); i++){
            if ( !isalnum(name[i]) ){
                cout << endl;
                cout << "Your username should be combination of digits or letters!";
                cout << endl ;
                cout << "Please reset your username!";
                cout << endl;
                setUsername();
                break;
            }
        }

        while (name.length() != 5){
            cout << "The length of the username should be 5!";
            cout << endl;
            cout << "Please reset your username!";
            cout << endl << endl;
            return setUsername();
        }

        return name;
    }

    string setPassword(){
        string psw1, psw2;
        cout << endl;
        cout << "\tSet your password: ";
        cin >> psw1;
        while(!checkPassword(psw1)) {
            cout << "\tSet your password: ";
            cin >> psw1;
        }

        cout << "\tRepeat your password: ";
        cin >> psw2;

        if (psw1==psw2){
            return psw1;
        }
        else{
            cout << endl;
            cout << "\t\tDifferent Password!" << endl;
            return setPassword();
        }
    }

    bool checkPassword(string& psw){
        for (int i=0; i<psw.length(); i++){
            if ( !isalnum(psw[i]) ){
                cout << endl;
                cout << "\nYour password should be combination of digits or letters!";
                cout << endl ;
                cout << "Please reset your password!";
                cout << endl;
                return 0;

            }
        }

        while (psw.length()!= 8){
            cout << "\nThe length of the password should be 8!";
            cout << endl;
            cout << "Please reset your password!";
            cout << endl << endl;
            return 0;

        }
        return 1;
    }

    void save_to_Txt(std::string playerinfo) {

        std::ofstream outFile;
        outFile.open("private.txt",std::ios::app);

        outFile << playerinfo;
        outFile << std::endl;

        outFile.close();

    }

    void save_to_bank(string pay_info) {

        std::ofstream outFile;
        outFile.open("bank.txt",std::ios::app);

        outFile << pay_info;
        outFile << std::endl;

        outFile.close();

    }


    QueryResult TextQuery::query(const std::string& sought) const {
        static std::shared_ptr<std::set<line_no>> nodata(new std::set<line_no>);
        auto loc = wm.find(sought);

        if (loc == wm.end())
            return QueryResult(sought, nodata, file);
        else
            return QueryResult(sought, loc->second, file);
    }

    string know_line(char *filename, int line){
        int lines, i = 0;
        string clause;
        fstream outfile;
        outfile.open(filename, ios::in);
        lines = enu_line(filename);

        while(getline(outfile, clause) && i < line-1) {
            i++;
        }
        outfile.close();
        return clause;
    }

    void Register(){
        cout << endl << endl;
        cout << "******************Register******************" << endl;
        cout << "-User Name should be combination of less than digits or letters.\n";

        string name, psd, psd1, psd2, new_psd;
        {


            cout << "-The length of username should be 5.";
            name = setUsername();

            ifstream infile;
            infile.open("private.txt");
            runQueries(infile);
            infile.close();

            if (line_num != 0) {
                cout << "username already exists, please change your username!" << endl;
                line_num = 0;

                cout << "-The length of username should be 5.";
                name = setUsername();

                ifstream infile;
                infile.open("private.txt");
                runQueries(infile);
                infile.close();

                if (line_num != 0) {
                    cout << "username already exists, please change your username!" << endl;
                    line_num = 0;
                    cout << "-The length of username should be 5.";
                    name = setUsername();

                }

            }

            cout << "\n-Password should be combination of 8 digits or letters";
            psd = setPassword();

            new_psd = TechnicalServices::Security::encryption(psd);

            save_to_Txt(name);
            save_to_Txt(new_psd);


            line_num = 0;
            Domain::GameRule::gameRuleController();
        }
    }

    void Login(){
        cout << "******************Login******************" << endl;

        ifstream infile;
        infile.open("private.txt");
        runQueries(infile);
        infile.close();

        if (line_num == 0) {
            cout << "You need register first!" << endl;
            UI::launch();

        }
        else {
            string psd_intxt, psd_login;

            do {
                cout << "\tEnter your password (type 'mainmenu' back to main menu): ";
                cin >> psd_login;
                if (psd_login == "mainmenu") {
                    UI::launch();
                }

                char filename[20] = "private.txt";

                psd_intxt = know_line(filename, line_num + 1);

                psd_intxt = TechnicalServices::Security::decode(psd_intxt);

                if (psd_login != psd_intxt) {
                    cout << "Wrong password!!" << endl;
                }

            } while (psd_login != psd_intxt);

            line_num = 0;
            Domain::GameRule::gameRuleController();

        }
    }

    void Logout(){
        std::cout << std::endl;
        std::cout << "\t\tBye_bye!" << std::endl;
    }
}

