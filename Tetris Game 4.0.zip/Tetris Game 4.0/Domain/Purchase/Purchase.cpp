#include "../Domain/Purchase/Purchase.h"
#include "../Domain/Purchase/PurchaseHandler.h"
#include "../Domain/GameRule/GameRuleHandler.h"
#include "../TechnicalServices/BankSystem/BankSys.h"

#include <iostream>

namespace Domain::Purchase {

    void displayPurchaseMenu() {

            std::cout << "************************************************************************************" << std::endl;
            std::cout << "Our game has 10 levels," << std::endl;
            std::cout << "the level will automatically increase when you reach a certain point of the score." << std::endl;
            std::cout << "Free to play, you could only has 1 to 3 levels," << std::endl;
            std::cout << "if a player want to unlock the rest of levels(4 to 10), he or she could purchase it." << std::endl;
            std::cout << "Pay -10 USD- for more fun!" << std::endl << std::endl;
        std::cout << "****************************************************************************************" << std::endl;
    }


    int inputChoice() {

        int payChoice;

        do {
            std::cout << "Do you want to unlock new game mode and have more fun ?!: " << std::endl;
            std::cout << "1: Yes" << std::endl;
            std::cout << "2: Still Yes" << std::endl;
//            std::cout << "3: Nope" << std::endl << std::endl;
            std::cout << "Your choice: ";

            std::cin >> payChoice;
        } while (payChoice != 1 && payChoice != 2
//        && payChoice != 3
        );

        return payChoice;
    }


    double makeChoice(int choice) {
        if (choice == 1 || choice == 2) {
            int cardType = inputCardTypeChoice();
            // card type has been decided.
            double total = makeCardTypeChoice(cardType);

            return total;
        }
        else {
//            Domain::GameRule::displayGameMenu();
        }
    }


    double makeCardTypeChoice(int choice) {

        if (choice == 1 || choice == 2 || choice == 3) {
            double total = (10 + (10.00 * creditCardAdaptor(choice)));

            return total;
        }
        else {
//            Domain::GameRule::displayGameMenu();
        }

    }


    int inputCardTypeChoice() {

        int cardChoice;

        do {
            std::cout << "\nPlease input your card type: " << std::endl;
            std::cout << "1: MasterCard" << std::endl;
            std::cout << "2: Visa" << std::endl;
            std::cout << "3: AmericanExpress" << std::endl;
//            std::cout << "4: Back to game menu" << std::endl;

            std::cout << "Your Choice: ";

            std::cin >> cardChoice;
        }while (cardChoice != 1 && cardChoice != 2 && cardChoice != 3
//        && cardChoice != 4
        );

        return cardChoice;
    }


    void getPayMenu(double total) {

        std::string cardholder;
        std::string cardnum;
        std::string securitynum;
        std::string month_year;

        std::cout << "******************************************************" << std::endl;
        std::cout << "Based on your credit card type, your total is : " << std::endl << total << "USD" << std::endl;
        std::cout << "******************************************************" << std::endl;
        std::cout << "Please input your pay card information" << std::endl;
        std::cout << "You could type 'exit' back to game menu" << std::endl << std::endl;

        std::cout << "cardholder name: ";
        std::cin >> cardholder;
        if (cardholder == "exit") {
            Domain::GameRule::displayGameMenu();
        }

        std::cout << "card number: ";
        std::cin >> cardnum;
        if (cardnum == "exit") {
            Domain::GameRule::displayGameMenu();
        }

        std::cout << "security number: ";
        std::cin >> securitynum;
        if (securitynum == "exit") {
            Domain::GameRule::displayGameMenu();
        }

        std::cout << "valid month/year (such as: 08/21): ";
        std::cin >> month_year;
        if (month_year == "exit") {
            Domain::GameRule::displayGameMenu();
        }

        TechnicalServices::BankSystem::save_to_bank(cardholder);
        TechnicalServices::BankSystem::save_to_bank(cardnum);
        TechnicalServices::BankSystem::save_to_bank(securitynum);
        TechnicalServices::BankSystem::save_to_bank(month_year);

        std::cout << std::endl << "Congratulations! You just got new game levels!" << std::endl;

    }






}