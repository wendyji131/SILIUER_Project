#ifndef TETRIS_PURCHASEHANDLER_H
#define TETRIS_PURCHASEHANDLER_H

namespace Domain::Purchase {

    void unlockNewMode();

    double creditCardAdaptor(int card);

}


#endif //TETRIS_PURCHASEHANDLER_H
