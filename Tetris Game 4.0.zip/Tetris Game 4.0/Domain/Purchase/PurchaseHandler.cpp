#include "../Domain/Purchase/PurchaseHandler.h"
#include "../Domain/Purchase/Purchase.h"
#include "../Domain/GameRule/GameRuleHandler.h"

#include <iostream>


namespace Domain::Purchase {

    void unlockNewMode() {

        displayPurchaseMenu();

        int choice = inputChoice();

        double total = makeChoice(choice);

        getPayMenu(total);

        Domain::GameRule::displayGameMenu();


        //--------
        std::cout << "unlockNewMode finished" << std::endl;


    };


    double creditCardAdaptor(int card) {
        double visa = 0.0245;
        double mastercard = 0.0212;
        double americanexpress = 0.0302;

        if (card == 1) {
            return visa;
        }else if (card == 2) {
            return mastercard;
        }else{
            return americanexpress;
        }
    }













}