#ifndef TETRIS_PURCHASE_H
#define TETRIS_PURCHASE_H

namespace Domain::Purchase {

    void displayPurchaseMenu();

    int inputChoice();

    double makeChoice(int choice);

    int inputCardTypeChoice();

    double makeCardTypeChoice(int choice);

    void getPayMenu(double total);



}


#endif //TETRIS_PURCHASE_H
