#include "RegisterLoginHandler.h"
#include "../UI/UIhandler.h"
#include "../Domain/RegisterLogin/RegisterLogin.h"

namespace Domain::RegisterLogin {
    void mainMenuController(int choice){
        if (choice == 1){
            return Domain::RegisterLogin::Login();
        }
        else if (choice == 2){
            return Domain::RegisterLogin::Register();
        }
        else if (choice == 3){
            return Domain::RegisterLogin::Logout();
        }
        else {
            UI::launch();
        }
    }

}