
#include "../Domain/RegisterLogin/RegisterLogin.h"

using namespace std;

namespace Domain::RegisterLogin {
    void mainMenuController(int choice);

} // namespace UI