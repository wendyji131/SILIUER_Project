#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <cstring>
#include <cstdio>
#include <iostream>
#include <string>
#include <cctype>
#include <fstream>
#include <sstream>
#include <vector>
#include <memory>
#include <set>
#include <map>

namespace Domain::RegisterLogin {


    bool checkPassword(std::string& psw);
    void save_to_Txt(std::string playerinfo);
    //void playGame();
    //void purchase();
    //void getpay();
    void save_to_bank(std::string pay_info);
    std::string setPassword();
    std::string setUsername();
    int enu_line(char *filename);
    std::string know_line(char *filename, int line);
    double getAmount(double sale);


    class QueryResult;
    class TextQuery;

    std::ostream& print(std::ostream& os, const QueryResult &qr);




    void Register();
    void Login();
    void Logout();
}
