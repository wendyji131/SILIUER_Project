//
// Created by wendyji on 12/5/18.
//

#include "Tetris.h"
#include "randomNumber.h"
#include "player.h"

#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <cstring>
#include <cstdio>
#include <iostream>
#include <string>
#include <cctype>
#include <fstream>
#include <sstream>
#include <vector>
#include <memory>
#include <set>
#include <map>

//using namespace std;

#define pieceSpd 321234
#define boardSize (17*24*sizeof(int))
#define pieceSize (3*3*sizeof(int))

unsigned long line_num = 0;
pthread_mutex_t	mutex_lock;
int num = 0;
static int pause_dot;
static randomNumber r;

namespace Domain::GameRule {
    void Tetris::piecePrint(pieceInterface *graph) {
        int x = 7;
        int y = 19;
        int i, j;

        cursor c;
        gameBoard p;
        c.saveCursor();
        c.moveCursor(6, 19);
        cout << "next : ";
        c.resetCursor();
        int a[3][3] = {0};

        memcpy(a, graph->fetchinfo(), pieceSize);

        for (i = x; i < x + 3; i++) {
            for (j = y; j < y + 3; j++) {
                p.decidePosition(i, j);
                p.decicol(CLEAR);
                p.printPoint();

                if (a[i - x][j - y] == 1) {
                    p.decicol(graph->decicol());
                    p.printPoint();
                }
            }
        }
    }


    void Tetris::prepTetris() {
        nextPiece = new pieceInterface(choosePiece());
        nextPiece->makeShape();
        nextPiece->decidePosition(1, 7);

        generatePiece();
    }


    gameState Tetris::fetchState() {
        return currt;
    }


    void Tetris::deciState(gameState currt) {
        this->currt = currt;
    }


    Tetris::~Tetris() {
        if (NULL != myPiece) {
            delete myPiece;
            myPiece = NULL;
        }

        if (NULL != nextPiece) {
            delete nextPiece;
            nextPiece = NULL;
        }
    }


    Tetris::Tetris() {
        int i;
        myPiece = NULL;
        x = 1;
        y = 7;
        gameBoard p;
        s.giveinfo();

        currt = stateRunning;

        memset((void *) tBoard, 0, boardSize);

        memset((void *) tCol, 0, boardSize);

        for (i = 0; i < 24; i++) {
            p.decidePosition(i, 0);
            p.decicol(GREN);
            p.printPoint();
            p.decidePosition(i, 16);
            p.decicol(GREN);
            p.printPoint();
            tBoard[i][0] = 1;
            tBoard[i][16] = 1;
        }

        for (i = 0; i < 17; i++) {
            p.decidePosition(23, i);
            p.decicol(GREN);
            p.printPoint();
            p.decidePosition(0, i);
            p.decicol(GREN);
            p.printPoint();
            tBoard[23][i] = 1;
            tBoard[0][i] = 1;
        }

        fflush(stdout);
    }


    bool Tetris::clearBoard() {
        int i;
        int j;
        int b[3][3] = {0};

        myPiece->makeit(CLEAR);
        memcpy(b, myPiece->fetchinfo(), pieceSize);

        for (i = 0; i < 3; i++) {
            for (j = 0; j < 3; j++) {
                tBoard[i + x][j + y] -= b[i][j];
                tCol[i][j] = CLEAR;
            }
        }
        return true;
    }


    bool Tetris::redoBoard() {
        int i;
        int j;
        int b[3][3] = {0};

        memcpy(b, myPiece->fetchinfo(), pieceSize);

        for (i = x; i < x + 3; i++) {
            for (j = y; j < y + 3; j++) {
                tBoard[i][j] += b[i - x][j - y];
                tCol[i][j] = myPiece->decicol();
            }
        }

        return true;
    }


    bool Tetris::prepBoard() {
        int i;
        int j;
        int b[3][3] = {0};

        myPiece->fetchposi(&x, &y);
        memcpy(b, myPiece->fetchinfo(), pieceSize);

        for (i = x; i < x + 3; i++) {
            for (j = y; j < y + 3; j++) {
                tBoard[i][j] += b[i - x][j - y];
                if (tBoard[i][j] > 1) {
                    cout << "Fin, good luck next time!" << endl;

                    system("stty icanon echo");
                    exit(0);
                }
            }
        }
        return true;
    }


//generate a random piece
    void Tetris::generatePiece() {
        myPiece = nextPiece;  //
        prepBoard();    //
        myPiece->makeit(YELLOW);    //
        nextPiece = new pieceInterface(choosePiece());
        nextPiece->makeShape();
        nextPiece->decidePosition(1, 7);
        piecePrint(nextPiece);
    }

/**********************************************************************/
/*the function choosePiece() show the concept of factory model pattern*/
/**********************************************************************/
    char Tetris::choosePiece() {
        char ch;
        //test: set the range of generate a random number from 1 to 4;
        //tetris can only generate three shapes: Z, T, and O.
        //switch (r.possibleX(1,4))


        //test to set the range of generate a random number from (1, 6)
        //tetris can generate 5 shapes: Z, T, O, I, and L.
        switch (r.possibleX(1, 6)) {
            case 1:
                ch = 'Z';
                break;
            case 2:
                ch = 'T';
                break;
            case 3:
                ch = 'O';
                break;
            case 4:
                ch = 'I';
                break;
            case 5:
                ch = 'L';
                break;
            default:
                ch = '\0';
                break;
        }

        return ch;
    }

    void Tetris::move(int dir) {
        if (stateRunning != currt)
            return;
        clearBoard();
        pthread_mutex_lock(&mutex_lock);

        switch (dir) {
            case DOWN:
                if (!checkDown()) {
                    myPiece->move(DOWN);
                    prepBoard();
                    myPiece->makeit(YELLOW);
                } else {
                    redoBoard();
                    myPiece->makeit(YELLOW);
                    eliminLine();
                    pauseTetris();
                }
                break;
            case LEFT:
                if (!checkL()) {
                    myPiece->move(LEFT);
                    prepBoard();
                    myPiece->makeit(YELLOW);
                } else {
                    redoBoard();
                    myPiece->makeit(YELLOW);
                }

                break;
            case RIGHT:
                if (!checkR()) {
                    myPiece->move(RIGHT);
                    prepBoard();
                    myPiece->makeit(YELLOW);
                } else {
                    redoBoard();
                    myPiece->makeit(YELLOW);
                }
                break;
            default:
                break;
        }
        pthread_mutex_unlock(&mutex_lock);
    }

    void Tetris::rotatePiece() {
        int i;
        int j;
        int flag = 0;
        int b[3][3] = {0};
        int temp[3][3] = {0};
        myPiece->fetchposi(&x, &y);
        memcpy(b, myPiece->fetchinfo(), pieceSize);
        clearBoard();

        for (i = 0; i < 3; i++) {
            for (j = 0; j < 3; j++) {
                temp[2 - j][i] = b[i][j];
            }
        }

        for (i = 0; i < 3; i++) {
            for (j = 0; j < 3; j++) {
                if (temp[i][j] == 1 && tBoard[x + i][y + j] == 1) {
                    flag = 1;
                    break;
                }
            }
            if (flag == 1)
                break;
        }

        if (flag == 0) {
            myPiece->rotatePiece();
        }

        prepBoard();
        myPiece->makeit(YELLOW);
    }


    void Tetris::pauseTetris() {
        delete myPiece;
        myPiece = NULL;
        pause_dot = 1;
        generatePiece();
    }


    bool Tetris::checkDown() {
        int i;
        int j;
        int cube_x, cube_y;
        int b[3][3] = {0};
        int flag = false;

        myPiece->fetchposi(&cube_x, &cube_y);
        memcpy(b, myPiece->fetchinfo(), pieceSize);

        for (i = 0; i < 3; i++) {
            for (j = 0; j < 3; j++) {
                if (b[i][j] == 1 && tBoard[i + cube_x + 1][j + cube_y] == 1) {
                    flag = true;
                    break;
                }
            }
            if (flag != 0)
                break;
        }

        return flag;
    }


    bool Tetris::checkL() {
        int i;
        int j;
        int cube_x, cube_y;
        int b[3][3] = {0};
        int flag = false;

        myPiece->fetchposi(&cube_x, &cube_y);
        memcpy(b, myPiece->fetchinfo(), pieceSize);

        for (i = 0; i < 3; i++) {
            for (j = 0; j < 3; j++) {
                if (b[i][j] == 1 && tBoard[i + cube_x][j + cube_y - 1] == 1) {
                    flag = true;
                    break;
                }
            }
            if (flag != 0)
                break;
        }

        return flag;
    }


    bool Tetris::checkR() {
        int i;
        int j;
        int cube_x, cube_y;
        int b[3][3] = {0};
        int flag = false;

        myPiece->fetchposi(&cube_x, &cube_y);
        memcpy(b, myPiece->fetchinfo(), pieceSize);

        for (i = 0; i < 3; i++) {
            for (j = 0; j < 3; j++) {
                if (b[i][j] == 1 && tBoard[i + cube_x][j + cube_y + 1] == 1) {
                    flag = true;
                    break;
                }
            }
            if (flag != 0)
                break;
        }

        return flag;
    }


    void Tetris::eliminLine() {
        int i;
        int j;
        int flag = 0;
        static int count = 0;

        for (i = 22; i > 0; i--) {
            for (j = 1; j < 16; j++) {
                if (tBoard[i][j] == 0) {
                    flag = 1;
                }
            }
            if (flag == 0) {
                count++;
                s.initialScore(count);
                s.giveinfo();
                dropPiece(i);
                i++;
            }
            flag = 0;
        }
    }


    void Tetris::dropPiece(int level) {
        int i, j;
        int flag = 1;

        for (i = level; i > 1; i--) {
            for (j = 1; j < 16; j++) {
                tBoard[i][j] = tBoard[i - 1][j];
            }
        }

        gameBoard p;

        for (i = 1; i < 23; i++) {
            for (j = 1; j < 16; j++) {
                if (tBoard[i][j] == 1) {
                    p.decidePosition(i, j);
                    p.decicol(tCol[i][j]);
                    p.printPoint();
                }
                if (tBoard[i][j] == 0) {
                    p.decidePosition(i, j);
                    p.decicol(CLEAR);
                    p.printPoint();
                }
            }
        }
    }


    void *checkNum(void *ptr) {
        Tetris *ptrg = (Tetris *) ptr;

        char numX;
        while (1) {
            system("stty -icanon -echo");
            numX = getchar();
            system("stty icanon echo");

            switch (numX) {
                case 'a':
                    ptrg->move(LEFT);
                    break;
                case 'd':
                    ptrg->move(RIGHT);
                    break;
                case 'w':
                    ptrg->rotatePiece();
                    break;
                case 's':

                    while (1) {
                        if (pause_dot == 1) {
                            pause_dot = 0;
                            break;
                        }
                        ptrg->move(DOWN);
                    }
                    break;

                case 'p':
                    if (stateRunning == ptrg->fetchState())
                        ptrg->deciState(stateP);
                    else
                        ptrg->deciState(stateRunning);
                    break;

                default:
                    break;
            }
        }
    }

    void Tetris::playGame() {
        pthread_t t1;
        pthread_mutex_init(&mutex_lock, NULL);
        system("clear");
        Tetris g;
        g.prepTetris();
        pthread_create(&t1, NULL, checkNum, (void *) (&g));

        while (1) {
            fflush(stdout);
            usleep(pieceSpd);
            g.move(DOWN);
        }
    }


}

