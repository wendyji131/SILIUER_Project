//
// Created by wendyji on 12/4/18.
//

#ifndef TETRIS_RANDOMNUMBER_H
#define TETRIS_RANDOMNUMBER_H


class randomNumber
{
public:
    //generate a random number between x and y
    int possibleX(int x,int y);
    randomNumber();
};


#endif //TETRIS_RANDOMNUMBER_H
