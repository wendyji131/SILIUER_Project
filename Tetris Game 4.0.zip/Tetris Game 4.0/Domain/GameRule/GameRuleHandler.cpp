//
// Created by wendyji on 12/7/18.
//
#include <iostream>
#include "GameRuleHandler.h"
#include "GameRule.h"
#include "UI.h"
#include "../Domain/Purchase/PurchaseHandler.h"

namespace Domain::GameRule{

    void gameRuleController(){
        displayGameMenu();
        int choice = makeChoice();
        if (choice == 1){
            return Domain::GameRule::playGame();
        }
        else if (choice == 2){
            return Domain::GameRule::gameInstruction();
        }
        else if (choice == 3){
            return Domain::GameRule::highScore();
        }
        else if (choice == 4){
            return Domain::Purchase::unlockNewMode();
        }
        else if (choice == 5){
            return Domain::GameRule::Logout();
        }
        else {
            std::cout << "Not legal choice!" << std::endl;
            return gameRuleController();
        }
    }

    void displayGameMenu(){
        std::cout << std::endl << std::endl;
        std::cout << "******************************************" << std::endl;
        std::cout << "******************TETRIS******************" << std::endl;
        std::cout << "******************************************" << std::endl;
        std::cout << std::endl << std::endl;
        std::cout << "          Play Game            (1)" << std::endl;
        std::cout << "          Game Instructions    (2)" << std::endl;
        std::cout << "          High Score           (3)" << std::endl;
        std::cout << "          Purchase             (4)" << std::endl;
        std::cout << "          Exit                 (5)" << std::endl;
        std::cout << std::endl;
        std::cout << std::endl;
    }

    int makeChoice(){
        std::cout << "Enter your choice: ";

        int choice;
        std::cin >> choice;

        while (choice <= 0 && choice >= 6){
            std::cout << "Your choice is not valid!" << std::endl;
            std::cout << "Please make a valid choice: ";
            std::cin >> choice;
        }




    }

}