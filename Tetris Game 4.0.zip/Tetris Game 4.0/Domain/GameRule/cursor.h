//
// Created by wendyji on 12/4/18.
//

#ifndef TETRIS_CURSOR_H
#define TETRIS_CURSOR_H


class cursor{
public:
    void saveCursor();	//save cursor
    void resetCursor();	//reset cursor
    void moveCursor(const int x,const int y);//move cursor to position (x,y)
};


#endif //TETRIS_CURSOR_H
