#include <iostream>
#include "GameRule.h"
#include "GameRuleHandler.h"
#include "Tetris.h"
namespace Domain::GameRule{
    void playGame(){
        Domain::GameRule::Tetris g;
        g.playGame();
    }

    void gameInstruction(){
        std::cout << std::endl << std::endl;
        std::cout << "*****************************************" << std::endl;
        std::cout << "************Game Instructions************" << std::endl;
        std::cout << "*****************************************" << std::endl;
        std::cout << std::endl << std::endl;
        std::cout << "\tPress W to rotate\n";
        std::cout << "\tPress A to move left\n";
        std::cout << "\tPress D to move right\n";
        std::cout << "\tPress S to speed down\n";
        std::cout << "\tPress P to pause game\n";
        gameRuleController();
    }

    void highScore(){
        std::cout << std::endl << "\t\tThis is for next Version!" << std::endl << std::endl;
        gameRuleController();
    }

    void Logout(){
        std::cout << std::endl << std::endl << "\t\tBye_bye!" << std::endl;
    }
}