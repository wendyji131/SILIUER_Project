#include <iostream>
#include "UI/UIhandler.h"
#include "UI/UI.h"
//#include "Domain/RegisterLogin/RegisterLoginHandler.h"

int main() {

    UI::launch();


    return 0;
}