#include "../TechnicalServices/Security/security.h"


namespace TechnicalServices::Security {
    
    std::string encryption(std::string& c){
        int a[] = {1, 3, 7, 9, 8, 6, 4, 0};
        for(int i = 0, j = 0; c[j];j++, i = (i + 1) % 8){
            
            c[j]+=a[i];
            
            if(c[j] > 122) c[j] -= 90;
        }
        return c;
    }
    
    
    std::string decode(std::string& c){
        std::string todo = c;
        
        int a[] = {1, 3, 7, 9, 8, 6, 4, 0};
        for(int i = 0, j = 0; todo[j];j++, i = (i + 1) % 8){
            
            todo[j]-=a[i];
            
            if(todo[j] < 32) todo[j] += 90;
        }
        
        return todo;
    }
    
    
}
