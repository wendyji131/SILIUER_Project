//
// Created by wendyji on 12/4/18.
//

#ifndef TETRIS_SIMPLELOGGER_H
#define TETRIS_SIMPLELOGGER_H

#endif //TETRIS_SIMPLELOGGER_H
