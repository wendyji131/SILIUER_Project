//
// Created by wendyji on 12/4/18.
//

#ifndef TETRIS_LOGGERHANDLER_H
#define TETRIS_LOGGERHANDLER_H
#include <iostream>
#include <string>



namespace UI
{

} // namespace UI
#endif //TETRIS_LOGGERHANDLER_H
