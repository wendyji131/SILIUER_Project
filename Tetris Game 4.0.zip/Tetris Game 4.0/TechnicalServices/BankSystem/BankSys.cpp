#include "BankSys.h"


namespace TechnicalServices::BankSystem {

    void save_to_bank(std::string pay_info) {

        std::ofstream outFile;
        outFile.open("bank.txt",std::ios::app);

        outFile << pay_info;
        outFile << std::endl;

        outFile.close();

    }

}
