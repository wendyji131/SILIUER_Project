#ifndef TETRIS_BANKSYS_H
#define TETRIS_BANKSYS_H

#include <fstream>

namespace TechnicalServices::BankSystem {

    void save_to_bank(std::string pay_info);

}



#endif //TETRIS_BANKSYS_H
