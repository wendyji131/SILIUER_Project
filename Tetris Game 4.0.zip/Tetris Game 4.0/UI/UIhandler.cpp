//
// Created by wendyji on 12/7/18.
//

#include "UIhandler.h"
#include "UI.h"
#include "../Domain/RegisterLogin/RegisterLoginHandler.h"
namespace UI {
    void launch(){
        displayMainMenu();
        int choice = makeChoice();
        Domain::RegisterLogin::mainMenuController(choice);
    }

}