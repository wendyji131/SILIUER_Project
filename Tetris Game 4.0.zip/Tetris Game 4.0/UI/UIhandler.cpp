//
// Created by wendyji on 12/7/18.
//

#include "../UI/UIhandler.h"
#include "../UI/UI.h"
#include "../Domain/RegisterLogin/RegisterLoginHandler.h"
namespace UI {
    void launch(){
        displayMainMenu();
        int choice = makeChoice();
        Domain::RegisterLogin::mainMenuController(choice);
    }

}