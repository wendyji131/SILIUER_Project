#include <stdio.h>

#include <iostream>
#include <sstream>
#include <fstream>

namespace UI{
    void displayMainMenu();
    int makeChoice();
}

