#include"../include/cursor.h"
#include<cstdio>
#include<cstdlib>

//move cursor to position (x,y)
void cursor::moveCursor(const int x,const int y) {
	int i;
	for(i = 0; i < y; i++) {
		printf("\33[2C");
	}

	for(i = 0; i < x; i++) {
		printf("\33[1B");
	}
}

//save cursor
void cursor::saveCursor() {
	printf("\33[s");	
}

//reset cursor
void cursor::resetCursor() {
	printf("\33[u");
}









