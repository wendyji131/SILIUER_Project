#include "../include/tetris.h"
#include "../include/randomNumber.h"
#include "../include/player.h"
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <cstring>
#include <cstdio>
#include <iostream>
#include <string>
#include <cctype>
#include <fstream>
#include <sstream>
#include <vector>
#include <memory>
#include <set>
#include <map>

using namespace std;

unsigned long line_num = 0;

#define pieceSpd 321234
#define boardSize (17*24*sizeof(int))
#define pieceSize (3*3*sizeof(int))

void mainMenu();
void gameMenu();
bool checkPassword(string& psw);
void save_to_Txt(std::string playerinfo);
void makeFun();
void purchase();
void getpay();
void save_to_bank(string pay_info);
string encryption(string& c);
string decode(string& c);
string setPassword();
string setUsername();
int enu_line(char *filename);
string know_line(char *filename, int line);

pthread_mutex_t	mutex_lock;
int num = 0;
static int pause_dot;
static randomNumber r;


int enu_line(char *filename) {
    ifstream outFile;
    int n = 0;
    string clause;

    outFile.open(filename, ios::in);
    
    if(outFile.fail()) {
        return 0;
    }
    else
    {
        while(getline(outFile, clause)) {
            n++;
        }
        outFile.close();
        
        return n;
    }
}

string know_line(char *filename, int line)
{
    int lines, i = 0;
    string clause;
    fstream outfile;
    outfile.open(filename, ios::in);
    lines = enu_line(filename);
    
    while(getline(outfile, clause) && i < line-1) {
        i++;
    }
    outfile.close();
    return clause;
}

void gameMenu(){
    cout << endl << endl;
    cout << "*****************************************" << endl;
    cout << "******************TETRIS******************" << endl;
    cout << "*****************************************" << endl;
    cout << endl << endl;
    cout << "          Play Game            (1)" << endl;
    cout << "          Game Instructions    (2)" << endl;
    cout << "          High Score           (3)" << endl;
    cout << "          Purchase             (4)" << endl;
    cout << "          Exit                 (5)" << endl;
    cout << endl;
    cout << endl;
    cout << "\tEnter your choice: ";
    
    int choice;
    cin >> choice;

    while (choice <= 0 && choice >= 6){
        cout << "\tYour choice is not valid!" << endl;
        cout << "\tPlease make a valid choice: ";
        cin >> choice;
    }
    
    switch(choice){
        case 1:
            makeFun();
            break;
        case 2:
            cout << endl << endl;
            cout << "*****************************************" << endl;
            cout << "************Game Instructions************" << endl;
            cout << "*****************************************" << endl;
            cout << endl << endl;
            cout << "\tPress W to rotate\n";
            cout << "\tPress A to move left\n";
            cout << "\tPress D to move right\n";
            cout << "\tPress S to speed down\n";
            cout << "\tPress P to pause game\n";
            gameMenu();
            break;
        case 3:
            cout << endl << endl;
            cout << "*****************************************" << endl;
            cout << "**************Highest Score**************" << endl;
            cout << "*****************************************" << endl;
            cout << endl << endl;
            cout << "\tYour highest score is: ";
            gameMenu();
            break;
        case 4:
            purchase();
            
            break;
        case 5:
            break;
    }
}

// From classical book: <<C++ prime>>
class QueryResult;
std::ostream& print(std::ostream& os, const QueryResult &qr);

class TextQuery {
public:
    using line_no = std::vector<std::string>::size_type;
    TextQuery(std::ifstream& );
    QueryResult query(const std::string& ) const;
private:
    std::shared_ptr<std::vector<std::string> > file;
    std::map<std::string, std::shared_ptr<std::set<line_no> >> wm;
};

TextQuery::TextQuery(std::ifstream &is) : file(new std::vector<std::string>) {
    std::string text;

    while (std::getline(is, text)) {

        file->push_back(text);
        auto n = file->size() - 1;
        std::istringstream line(text);
        std::string word;

        while (line >> word) {
            auto& lines = wm[word];
            if (!lines)
                lines.reset(new set<line_no>);
            lines->insert(n);
        }
    }
}

class QueryResult {
    friend std::ostream& print (std::ostream&, const QueryResult& );
public:
    using line_no = std::vector<std::string>::size_type;

    QueryResult (std::string s,
                 std::shared_ptr<std::set<line_no>> p,
                 std::shared_ptr<std::vector<std::string>> f) :
            sought(s), lines(p), file(f) {}

private:
    std::string sought;
    std::shared_ptr<std::set<line_no>> lines;
    std::shared_ptr<std::vector<std::string>> file;
};


QueryResult TextQuery::query(const std::string& sought) const {
    static std::shared_ptr<std::set<line_no>> nodata(new std::set<line_no>);
    auto loc = wm.find(sought);

    if (loc == wm.end())
        return QueryResult(sought, nodata, file);
    else
        return QueryResult(sought, loc->second, file);
};


std::string make_plural (std::size_t ctr, const std::string& word, const std::string ending) {
    return (ctr > 1) ? word + ending : word;
}

std::ostream& print(std::ostream& os, const QueryResult &qr) {

    for(auto num : *qr.lines) {
        line_num = num + 1;
    }
    return os;
}


void runQueries (std::ifstream &infile) {
    TextQuery tq(infile);

    cout << "\tEnter your user name: ";
    std::string s;
    cin >> s;

    print(std::cout, tq.query(s)) << std::endl;

}


string setUsername(){
    string name;
    cout << endl << endl;
    cout << "\tEnter your user name: ";
    cin >> name;
    for (int i=0; i<name.length(); i++){
        if ( !isalnum(name[i]) ){
            cout << endl;
            cout << "Your username should be combination of digits or letters!";
            cout << endl ;
            cout << "Please reset your username!";
            cout << endl;
            setUsername();
            break;
        }
    }

    while (name.length() != 5){
        cout << "The length of the username should be 5!";
        cout << endl;
        cout << "Please reset your username!";
        cout << endl << endl;
        return setUsername();
    }
    
    return name;
}


string setPassword(){
    string psw1, psw2;
    cout << endl;
    cout << "\tSet your password: ";
    cin >> psw1;
    while(!checkPassword(psw1)) {
        cout << "\tSet your password: ";
        cin >> psw1;
    }
    
    cout << "\tRepeat your password: ";
    cin >> psw2;

    if (psw1==psw2){
        return psw1;
    }
    else{
        cout << endl;
        cout << "\t\tDifferent Password!" << endl;
        return setPassword();
    }
}


bool checkPassword(string& psw){
    for (int i=0; i<psw.length(); i++){
        if ( !isalnum(psw[i]) ){
            cout << endl;
            cout << "\nYour password should be combination of digits or letters!";
            cout << endl ;
            cout << "Please reset your password!";
            cout << endl;
            return 0;
            
        }
    }

    while (psw.length()!= 8){
        cout << "\nThe length of the password should be 8!";
        cout << endl;
        cout << "Please reset your password!";
        cout << endl << endl;
        return 0;
        
    }
    return 1;
}

void save_to_Txt(std::string playerinfo) {

    std::ofstream outFile;
    outFile.open("private.txt",std::ios::app);
    
    outFile << playerinfo;
    outFile << std::endl;
    
    outFile.close();
    
}


void purchase() {
    
    string pay_choice;
    
    cout << "*****************************************" << endl;
    cout << "Our game has 10 levels," << endl;
    cout << "the level will automaticallyy increase when you reach a certain point of the score." << endl;
    cout << "Free to play, you could only has 1 to 3 levels," << endl;
    cout << "if a player want to unlock the rest of levels(4 to 10), he or she could purchase it(5 USD)." << endl;
    cout << "Pay for more fun!" << endl << endl;
    
    do {
        cout << "Do you want to unlock new levels? yes/no: ";
        cin >> pay_choice;
    } while (pay_choice != "yes" && pay_choice != "no");
    
    if (pay_choice == "yes") {
        getpay();
    } else {
        gameMenu();
    }
    
}


void getpay() {
    
    string cardholder;
    string cardnum;
    string securitynum;
    string month_year;
    
    cout << "*****************************************" << endl;
    cout << "Please input your pay card infomation" << endl;
    cout << "You could type 'exit' back to game menu" << endl << endl;
    
    cout << "cardholder name: ";
    cin >> cardholder;
    if (cardholder == "exit") {
        gameMenu();
    }
    
    cout << "card number: ";
    cin >> cardnum;
    if (cardnum == "exit") {
        gameMenu();
    }
    
    cout << "security number: ";
    cin >> securitynum;
    if (securitynum == "exit") {
        gameMenu();
    }
    
    cout << "valid month/year (such as: 08/21): ";
    cin >> month_year;
    if (month_year == "exit") {
        gameMenu();
    }
    
    save_to_bank(cardholder);
    save_to_bank(cardnum);
    save_to_bank(securitynum);
    save_to_bank(month_year);
    
    cout << endl << "Congratulations! You just got new game levels!" << endl;
    
    gameMenu();
    
}


void save_to_bank(string pay_info) {
    
    std::ofstream outFile;
    outFile.open("bank.txt",std::ios::app);
    
    outFile << pay_info;
    outFile << std::endl;
    
    outFile.close();
    
}


string encryption(string& c){
    int a[] = {1, 3, 7, 9, 8, 6, 4, 0};
    for(int i = 0, j = 0; c[j];j++, i = (i + 1) % 8){
        
        c[j]+=a[i];
        
        if(c[j] > 122) c[j] -= 90;
    }
    return c;
}


string decode(string& c){
    string todo = c;

    int a[] = {1, 3, 7, 9, 8, 6, 4, 0};
    for(int i = 0, j = 0; todo[j];j++, i = (i + 1) % 8){
        
        todo[j]-=a[i];
        
        if(todo[j] < 32) todo[j] += 90;
    }

    return todo;
}


void Tetris::piecePrint(pieceInterface* graph) {
    int x = 7;
    int y = 19;
    int i,j;

    cursor c;
    gameBoard p;
    c.saveCursor();
    c.moveCursor(6,19);
    cout<<"next : ";
    c.resetCursor();
    int a[3][3] = {0};

    memcpy(a,graph->fetchinfo(),pieceSize);

    for(i = x; i < x+3; i++) {
        for (j = y; j < y + 3; j++) {
            p.decidePosition(i, j);
            p.decicol(CLEAR);
            p.printPoint();

            if (a[i - x][j - y] == 1) {
                p.decicol(graph->decicol());
                p.printPoint();
            }
        }
    }
}


void Tetris::prepTetris() {
    nextPiece = new pieceInterface(choosePiece());
    nextPiece->makeShape();
    nextPiece->decidePosition(1,7);

    generatePiece();
}


gameState Tetris::fetchState() {
	return currt;
}


void Tetris::deciState( gameState currt ) {
	this->currt = currt;
}


Tetris::~Tetris() {
	if( NULL != myPiece ) {
		delete myPiece;
        myPiece = NULL;
	}

	if( NULL != nextPiece ) {
		delete nextPiece;
        nextPiece = NULL;
	}
}


Tetris::Tetris() {
    int i;
    myPiece = NULL;
    x = 1;
    y = 7;
    gameBoard p;
    s.giveinfo();

    currt = stateRunning;

    memset((void*)tBoard,0,boardSize);

	memset((void*)tCol,0,boardSize);

	for(i = 0; i < 24; i++) {
        p.decidePosition(i,0);
        p.decicol(GREN);
        p.printPoint();
        p.decidePosition(i,16);
        p.decicol(GREN);
        p.printPoint();
        tBoard[i][0] = 1;
        tBoard[i][16] = 1;
   }

   for(i = 0; i < 17; i++) {
        p.decidePosition(23,i);
        p.decicol(GREN);
        p.printPoint();
        p.decidePosition(0,i);
        p.decicol(GREN);
        p.printPoint();
        tBoard[23][i] = 1;
        tBoard[0][i] = 1;
   }
   
   fflush(stdout);
}




bool Tetris::clearBoard() {
    int i;
    int j;
    int b[3][3] = {0};

    myPiece->makeit(CLEAR);
    memcpy(b,myPiece->fetchinfo(),pieceSize);

    for(i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            tBoard[i + x][j + y] -= b[i][j];
            tCol[i][j] = CLEAR;
        }
    }
    return true;
}


bool Tetris::redoBoard() {
    int i;
    int j;
    int b[3][3] = {0};

    memcpy(b,myPiece->fetchinfo(),pieceSize);

    for(i = x; i < x + 3; i++) {
        for (j = y; j < y + 3; j++) {
            tBoard[i][j] += b[i - x][j - y];
            tCol[i][j] = myPiece->decicol();
        }
    }

    return true;
}


bool Tetris::prepBoard() {
    int i;
    int j;
    int b[3][3] = {0};

    myPiece->fetchposi(&x,&y);
    memcpy(b,myPiece->fetchinfo(),pieceSize);
   
    for(i = x; i < x + 3; i++) {
        for (j = y; j < y + 3; j++) {
            tBoard[i][j] += b[i - x][j - y];
            if (tBoard[i][j] > 1) {
                cout << "Fin, good luck next time!" << endl;

                system("stty icanon echo");
                exit(0);
            }
        }
    }
    return true;
}


//generate a random piece
void Tetris::generatePiece()  {
    myPiece = nextPiece;  //
    prepBoard();    //
    myPiece->makeit(YELLOW);    //
    nextPiece = new pieceInterface(choosePiece());
    nextPiece->makeShape();
    nextPiece->decidePosition(1,7);
    piecePrint(nextPiece);
}

/**********************************************************************/
/*the function choosePiece() show the concept of factory model pattern*/
/**********************************************************************/
char Tetris::choosePiece() {
    char ch;
    //test: set the range of generate a random number from 1 to 4;
    //tetris can only generate three shapes: Z, T, and O.
    //switch (r.possibleX(1,4))


    //test to set the range of generate a random number from (1, 6)
    //tetris can generate 5 shapes: Z, T, O, I, and L.
    switch(r.possibleX(1,6))
    {
        case 1:
            ch = 'Z';
            break;
        case 2:
            ch = 'T';
            break;
        case 3:
            ch = 'O';
            break;
        case 4:
            ch = 'I';
            break;
        case 5:
            ch = 'L';
            break;
        default:
            ch = '\0';
            break;
    }

    return ch;
}

void Tetris::move(int dir) {
	if(stateRunning != currt)
		return;
    clearBoard();
    pthread_mutex_lock(&mutex_lock);

    switch(dir)
    {
        case DOWN:
            if(!checkDown()) {
                myPiece->move(DOWN);
                prepBoard();
                myPiece->makeit(YELLOW);
            }
            else {
                redoBoard();
                myPiece->makeit(YELLOW);
                eliminLine();
                pauseTetris();
            }
            break;
        case LEFT:
            if(!checkL()) {
                myPiece->move(LEFT);
                prepBoard();
                myPiece->makeit(YELLOW);
            }
            else {
                redoBoard();
                myPiece->makeit(YELLOW);
            }
 
            break;
        case RIGHT:
            if(!checkR()) {
                myPiece->move(RIGHT);
                prepBoard();
                myPiece->makeit(YELLOW);
            }
            else {
                redoBoard();
                myPiece->makeit(YELLOW);
            }
            break;
        default:
            break;
    }
    pthread_mutex_unlock(&mutex_lock);
}

void Tetris::rotatePiece() {
    int i;
    int j;
    int flag = 0;
    int b[3][3] = {0};
    int temp[3][3] = {0};
    myPiece->fetchposi(&x,&y);
    memcpy(b,myPiece->fetchinfo(),pieceSize);
    clearBoard();
    
    for(i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            temp[2 - j][i] = b[i][j];
        }
    }
   
    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
            if (temp[i][j] == 1 && tBoard[x + i][y + j] == 1) {
                flag = 1;
                break;
            }
        }
        if(flag == 1)
            break;
    }

    if(flag == 0) {
        myPiece->rotatePiece();
    }

    prepBoard();
    myPiece->makeit(YELLOW);
}


void Tetris::pauseTetris() {
    delete myPiece;
    myPiece = NULL;
    pause_dot = 1;
    generatePiece();
}


bool Tetris::checkDown() {
    int i;
    int j;
    int cube_x,cube_y;
    int b[3][3] = {0};
    int flag = false;

    myPiece->fetchposi(&cube_x,&cube_y);
    memcpy(b,myPiece->fetchinfo(),pieceSize);

    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
           if (b[i][j] == 1 && tBoard[i + cube_x + 1][j + cube_y] == 1) {
                flag = true;
                break;
           }
        }
        if (flag != 0)
            break;
    }

    return flag;
}


bool Tetris::checkL() {
    int i;
    int j;
    int cube_x,cube_y;
    int b[3][3] = {0};
    int flag = false;

    myPiece->fetchposi(&cube_x,&cube_y);
    memcpy(b,myPiece->fetchinfo(),pieceSize);

    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
           if (b[i][j] == 1 && tBoard[i + cube_x][j + cube_y - 1] == 1) {
                flag = true;
                break;
           }
        }
        if (flag != 0)
            break;
    }

    return flag;
}


bool Tetris::checkR() {
    int i;
    int j;
    int cube_x,cube_y;
    int b[3][3] = {0};
    int flag = false;

    myPiece->fetchposi(&cube_x,&cube_y);
    memcpy(b,myPiece->fetchinfo(),pieceSize);

    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
           if (b[i][j] == 1 && tBoard[i + cube_x][j + cube_y + 1] == 1) {
                flag = true;
                break;
           }
        }
        if (flag != 0)
            break;
    }

    return flag;
}


void Tetris::eliminLine() {
   int i;
   int j;
   int flag = 0;
   static int count = 0;

   for(i = 22; i > 0; i--) {
        for(j = 1; j < 16; j++) {
            if(tBoard[i][j] == 0) {
                flag = 1;
            }
        }
        if(flag == 0) {
            count++;
            s.initialScore(count);
            s.giveinfo();
            dropPiece(i);
            i++;
        }
        flag = 0;
   }
}


void Tetris::dropPiece(int level) {
    int i,j;
    int flag = 1;

    for(i = level; i > 1; i--) {
        for (j = 1; j < 16; j++) {
            tBoard[i][j] = tBoard[i - 1][j];
        }
    }

    gameBoard p;

    for(i = 1; i < 23; i++) {
        for (j = 1; j < 16; j++) {
            if (tBoard[i][j] == 1) {
                p.decidePosition(i, j);
                p.decicol(tCol[i][j]);
                p.printPoint();
            }
            if (tBoard[i][j] == 0) {
                p.decidePosition(i, j);
                p.decicol(CLEAR);
                p.printPoint();
            }
        }
    }
}


void* checkNum(void *ptr)
{
    Tetris* ptrg = (Tetris*)ptr;

    char numX;
    while(1)
    {
        system("stty -icanon -echo");
        numX = getchar();
        system("stty icanon echo");

        switch(numX) {
            case 'a':
                ptrg->move(LEFT);
                break;
            case 'd':
                ptrg->move(RIGHT);
                break;
            case 'w':
                ptrg->rotatePiece();
                break;
            case 's':
                
                while(1) {
                    if(pause_dot == 1) {
                        pause_dot = 0;
                        break;
                    }
                    ptrg->move(DOWN);
                }
                break;

            case 'p':
		        if(stateRunning == ptrg->fetchState())
			        ptrg->deciState(stateP);
		        else
		            ptrg->deciState(stateRunning);
                break;

            default:
                break;
        }
    }
}


void mainMenu(){
    cout << endl << endl;
    cout << "*****************************************" << endl;
    cout << "******Welcome To Tetris Game System******" << endl;
    cout << "*****************************************" << endl;
    cout << endl << endl;
    cout << "          Login    (1)" << endl;
    cout << "          Register (2)" << endl;
    cout << "          Exit     (3)" << endl;
    cout << endl;
    cout << endl;
    cout << "\tEnter your choice: ";
    int choice;
    cin >> choice;

    while (choice != 1 && choice != 2 && choice != 3){
        cout << "\tYour choice is not valid!" << endl;
        cout << "\tPlease make a valid choice: ";
        cin >> choice;
    }
    string name_login, psd_login, name, psd;
    string new_psd;
    string db_psd = "25:=<961";
    switch(choice){
        case 1:
        {
            cout << "******************Login******************" << endl;
            
            ifstream infile;
            infile.open("private.txt");
            runQueries(infile);
            infile.close();
            
            if (line_num == 0) {
                cout << "You need register first!" << endl;
                mainMenu();
                
            } else {
                string psd_intxt;
                
                do {
                    cout << "\tEnter your password (type 'mainmenu' back to main menu): ";
                    cin >> psd_login;
                    if (psd_login == "mainmenu") {
                        mainMenu();
                    }
                    
                    char filename[20] = "private.txt";

                    psd_intxt = know_line(filename, line_num + 1);

                    psd_intxt = decode(psd_intxt);
                    
                    if (psd_login != psd_intxt) {
                        cout << "Wrong password!!" << endl;
                    }
                    
                } while (psd_login != psd_intxt);
                
                line_num = 0;
                gameMenu();
                
            }
        }
            break;
            
        case 2:

            cout << endl << endl;
            cout << "******************Register******************" << endl;
            cout << "-User Name should be combination of less than digits or letters.\n";

        {
            

                cout << "-The length of username should be 5.";
                name = setUsername();
                
                ifstream infile;
                infile.open("private.txt");
                runQueries(infile);
                infile.close();
                
                if (line_num != 0) {
                    cout << "username already exists, please change your username!" << endl;
                    line_num = 0;
                    
                    cout << "-The length of username should be 5.";
                    name = setUsername();
                    
                    ifstream infile;
                    infile.open("private.txt");
                    runQueries(infile);
                    infile.close();
                    
                    if (line_num != 0) {
                        cout << "username already exists, please change your username!" << endl;
                        line_num = 0;
                        cout << "-The length of username should be 5.";
                        name = setUsername();
                        
                    }
                    
                }

            cout << "\n-Password should be combination of 8 digits or letters";
            psd = setPassword();

            new_psd = encryption(psd);

            save_to_Txt(name);
            save_to_Txt(new_psd);
            
            
            line_num = 0;
            gameMenu();
        }

            break;
            
        case 3:
            
            break;
    }
}


void makeFun() {

    pthread_t t1;
    pthread_mutex_init(&mutex_lock, NULL);
    system("clear");
    Tetris g;
    g.prepTetris();
    pthread_create(&t1,NULL,checkNum,(void*)(&g));
    
    while(1) {
        fflush(stdout);
        usleep(pieceSpd);
        g.move(DOWN);
    }
}


int main() {
    mainMenu();
	return 0;
}
