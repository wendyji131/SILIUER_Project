#ifndef CURSOR_H_
#define CURSOR_H_

#include<iostream>

using namespace std;

class cursor{
public:
	void saveCursor();	//save cursor
	void resetCursor();	//reset cursor
	void moveCursor(const int x,const int y);//move cursor to position (x,y)
};
#endif

