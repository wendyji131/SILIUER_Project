#ifndef RANDOMNUMBER_H
#define RANDOMNUMBER_H
class randomNumber
{
public:
    //generate a random number between x and y
    int possibleX(int x,int y);
    randomNumber();
};

#endif
