#include <iostream>
#include <stdio.h>
#include "gameBoard.h"
#include <stdlib.h>

#define DOWN 0
#define LEFT 1
#define RIGHT 2

using namespace std;

//factory method design pattern
//factory: piece is an abstract factory producing different shape pieces
//concrete products: pieceZ, pieceL, pieceI, pieceO, pieceT are concrete products of piece
//interface: pieceInterface


//pieceShape is the factory
class pieceShape{
public:
	pieceShape(){
		int i,j;
		x = 0;
		y = 0;
		for(j = 0; j < 3; j++)
		for(i = 0; i < 3; i++)
		a[i][j] = 0;
	}

	int move(int dir);
	virtual int rotatePiece();

	//get the positon of the vertex
    void fetchposi(int* a,int* b){
    	*a = x;*b = y;
    }

    void makeit(int pigment);

	void* fetchinfo(){
		return (void*)a;
	}

	virtual void makeShape(){

	}

	void decidePosition(int a,int b){
		x = a;y = b;
	}

protected:
	int x, y;
	int a[3][3];

};

//pieceT is a concrete product of pieceShape
class pieceT : public pieceShape{
public:
    void makeShape(){
        a[0][0] = 1;
        a[0][1] = 1;
        a[0][2] = 1;
        a[1][0] = 0;
        a[1][1] = 1;
        a[1][2] = 0;
        a[2][0] = 0;
        a[2][1] = 0;
        a[2][2] = 0;
    }
};

//pieceZ is a concrete product of pieceShape
class pieceZ : public pieceShape{
public:
	void makeShape(){
		a[0][0] = 1;
		a[0][1] = 1;
		a[0][2] = 0;
		a[1][0] = 0;
		a[1][1] = 1;
		a[1][2] = 1;
		a[2][0] = 0;
		a[2][1] = 0;
		a[2][2] = 0;
	}
};

//piece0 is a concrete product of pieceShape
class pieceO : public pieceShape{
public:
	void makeShape(){
		a[0][0] = 1;
		a[0][1] = 1;
		a[0][2] = 0;
		a[1][0] = 1;
		a[1][1] = 1;
		a[1][2] = 0;
		a[2][0] = 0;
		a[2][1] = 0;
		a[2][2] = 0;
	}
	virtual int rotatePiece(){}
};


//pieceL is a concrete product of pieceShape
class pieceL : public pieceShape{
public:
	void makeShape(){
		a[0][0] = 0;
		a[0][1] = 1;
		a[0][2] = 0;
		a[1][0] = 0;
		a[1][1] = 1;
		a[1][2] = 0;
		a[2][0] = 0;
		a[2][1] = 1;
		a[2][2] = 1;
	}
};

//pieceI is a concrete product of pieceShape
class pieceI : public pieceShape{
public:
    void makeShape(){
        a[0][0] = 0;
        a[0][1] = 1;
        a[0][2] = 0;
        a[1][0] = 0;
        a[1][1] = 1;
        a[1][2] = 0;
        a[2][0] = 0;
        a[2][1] = 1;
        a[2][2] = 0;
    }
};


class pieceInterface
{
private:
	pieceShape* pShape;
    pigment clr;

public:
    ~pieceInterface()
    {
        delete pShape;
    }
	pieceInterface(char s)
	{
		switch(s)
		{
			case 'Z':
				pShape = new pieceZ();
				clr = PURPLE;
				break;
			case 'T':
				pShape = new pieceT();
				clr = PURPLE;
				break;
			case 'O':
				pShape = new pieceO();
				clr = PURPLE;
				break;
			case 'I':
				pShape = new pieceI();
				clr = PURPLE;
				break;
			case 'L':
				pShape = new pieceL();
				clr = PURPLE;
				break;
			default:
				break;
		}
	}

	int move(int dir){
    	return pShape->move(dir);
    }

	int rotatePiece(){
    	return pShape->rotatePiece();
    }

	void makeShape(){
		pShape->makeShape();
    }

	void decidePosition(int a,int b){
		pShape->decidePosition(a,b);
    }

    void fetchposi(int *a,int* b){
		pShape->fetchposi(a,b);
    }

    void* fetchinfo(){
		pShape->fetchinfo();
    }

    void makeit(int pigment){
	if(pigment == CLEAR)
		pShape->makeit(CLEAR);
	else pShape->makeit(clr);
	}

	void decicol(pigment clr) {
		this->clr = clr;
	}

    pigment decicol() {
	return clr;
	}
};

