#include "pieceShape.h"
#include "randomNumber.h"
#include "Score.h"

enum gameState{
	stateP = 0,
	stateRunning = 1
};


class Tetris {
public:
    int x;
    int y;
	Tetris();
	~Tetris();
	gameState fetchState();
    void generatePiece();	//generate a random piece
    void rotatePiece();		//rotate piece
    void pauseTetris();		//pause tetris
    void eliminLine();		//erase a line
	void move(int dir);		//move piece
    void dropPiece(int level);	//fast move down
	void prepTetris();		//prepare(initiate) Tetris
	void deciState( gameState );	//decide Tetris state: pause or run
	void piecePrint(pieceInterface* myPiece);	//print next piece

private:
	Score s;
	int tBoard[24][17];
	pigment tCol[24][17];
	pieceInterface* myPiece;
	pieceInterface* nextPiece;	//next piece
	gameState currt;
	bool redoBoard();	//
	bool checkDown();	//check the bottom of the board
	bool checkR();		//check the right wall of the board
	char choosePiece();	//generate a random piece
	bool prepBoard();	//prepare(initiate) the board
	bool clearBoard();	//clear the board
	bool checkL();		//check the left wall of the board
};
