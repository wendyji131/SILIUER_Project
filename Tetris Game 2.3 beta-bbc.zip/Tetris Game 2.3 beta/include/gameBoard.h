#ifndef gameBoard_H_
#define gameBoard_H_

#include<iostream>
#include "cursor.h"

using namespace std;

enum pigment{
	CLEAR = 0, BLACK = 30, YELLOW, PURPLE, GREN
};
//print the game board
class gameBoard{
public:
    gameBoard() {
        pigment = CLEAR;
		x = 0;
		y = 0;
	}

    gameBoard(int a,int b,int c) {
        pigment = a;
		x = b;
		y = c;
	}

    int decicol(){
        return pigment;
    }

	void decidePosition(const int x,const int y){
        this->x = x;
        this->y = y;
    }

	void decicol(const int pigment){
        this->pigment = pigment;
    }

	void fetchposi(int&x,int &y){
        x = this->x;
        y = this->y;
    }

	void printPoint();

protected:
	int x, y, pigment;
};
#endif

