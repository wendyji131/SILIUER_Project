#ifndef gameScore_H
#define gameScore_H

#include <iostream>
#include <string>

using namespace std;

class Score{
public:
    int score;
    string player;

    Score(){
        player = "Toni";
        score = 0;
    };

    void giveinfo();
    void initialScore(int s){
        score = s;
    };
};

#endif
